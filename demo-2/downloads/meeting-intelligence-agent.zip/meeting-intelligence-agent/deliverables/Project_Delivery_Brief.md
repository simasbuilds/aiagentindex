# Project Delivery Brief — Internal Request/Approval Process Replacement

**Prepared by:** Meeting Intelligence Review (PM/BA)
**Date prepared:** 2026-07-13
**Sources reviewed:**
- `Realistic_Teams_Transcript_1.pdf` — "Project Kickoff"
- `Realistic_Teams_Transcript_2.pdf` — "Requirements Gathering"
- `Realistic_Teams_Transcript_3.pdf` — "Discovery Session"

**Attendees (all three sessions):** Sarah (Project Manager), Mike (Business Analyst), Emily (Stakeholder), David (Developer), Lisa (Product Owner)

---

## ⚠ Data-Quality Flag — Read First

The dialogue, timestamps, and action items in **Transcript 1, Transcript 2, and Transcript 3 are word-for-word identical**. The only differences across the three files are the cover title ("Project Kickoff" / "Requirements Gathering" / "Discovery Session") and a single one-line "Project Context" description. No new statements, decisions, or attendees appear in the second or third transcript that were not already in the first.

**Implication:** This brief treats the content as **one evidentiary source that happens to be filed three times**, not as three independent meetings that built on each other. Every finding below is cited to all three transcripts where it appears (since it appears identically in all three), but reviewers should not read this as corroboration by three separate conversations — it is the same conversation. This should be raised with the meeting owner before the next workshop (see Follow-Up Questions).

---

## 1. Executive Summary

The business wants to replace a manual, spreadsheet-driven internal request process with a simple internal application. Under the current process, a request is submitted, a manager reviews it, and finance approves it if it exceeds an unspecified dollar threshold (Transcripts 1–3, [06:00]). The stakeholder (Emily) reports that the process "works" but is slow because staff re-enter the same information in multiple systems, and most systems are not integrated (Transcripts 1–3, [02:00], [14:00]). The largest time losses are approval waiting time and manual spreadsheet updates (Transcripts 1–3, [10:00]).

The team agreed to a minimum-viable first release that targets the biggest pain points rather than full scope, with room to add features later (Transcripts 1–3, [16:00]–[18:00]). Daily users will span Operations, Managers, and Finance, and the system will require role-based permissions since managers need visibility into different information than regular employees (Transcripts 1–3, [22:00], [26:00]). Monthly summary reporting was named the top-priority report (Transcripts 1–3, [36:00]). The only timing signal captured is a target of "before next quarter" (Transcripts 1–3, [32:00]) — no specific date, quarter, or year was confirmed.

The meeting closed with four action items (document requirements, send sample reports, review existing systems, schedule the next workshop) but **no owner assigned a due date for any of them** except the next workshop, which was informally set for "next week" (Transcripts 1–3, [46:00]). Significant information gaps remain, most notably the exact approval dollar threshold, the specific systems currently in use, and a confirmed delivery date — all labeled **Not confirmed** below.

---

## 2. Business Problem & Current-State Workflow

| Element | Finding | Source |
|---|---|---|
| Problem statement | Current process "works, but it takes too long because people enter the same information in multiple places" | T1/T2/T3 [02:00] |
| Workflow steps | (1) Request submitted → (2) Manager reviews → (3) Finance approves **if over a certain amount** | T1/T2/T3 [06:00] |
| Approval threshold amount | **Not confirmed** — referred to only as "a certain amount," no figure given | T1/T2/T3 [06:00] |
| Biggest time loss | Waiting for approvals; manually updating spreadsheets | T1/T2/T3 [10:00] |
| System integration state | "Most of it is manual today" — systems are largely not connected | T1/T2/T3 [12:00]–[14:00] |
| Specific current systems in use | **Not confirmed** — named systems (e.g., which spreadsheets, which finance tool) not stated | — |

## 3. Users & Stakeholders

| Person | Role in project | Evidence |
|---|---|---|
| Sarah | Project Manager, meeting facilitator | T1/T2/T3 [00:00], [30:00], [42:00], [46:00] |
| Mike | Business Analyst, leads requirements documentation | T1/T2/T3 [04:00], [08:00], [20:00], [28:00], [40:00] |
| Emily | Business stakeholder, primary source of current-state and requirements input | T1/T2/T3 throughout |
| David | Developer, assesses technical/systems feasibility | T1/T2/T3 [12:00], [24:00], [38:00] |
| Lisa | Product Owner, scopes MVP and prioritizes reporting | T1/T2/T3 [16:00], [34:00] |
| Daily end users | Operations, Managers, Finance | T1/T2/T3 [22:00] |

## 4. Confirmed Requirements & Constraints

| # | Requirement/Constraint | Status | Source |
|---|---|---|---|
| R1 | First release ("v1") should target the biggest pain points, not full scope; additional features deferred to later releases | Confirmed (decision) | T1/T2/T3 [16:00]–[18:00] |
| R2 | Role-based permissions required; managers must see different information than regular employees | Confirmed | T1/T2/T3 [24:00]–[26:00] |
| R3 | Daily users include Operations, Managers, and Finance | Confirmed | T1/T2/T3 [22:00] |
| R4 | Monthly summary reports are the top reporting priority | Confirmed | T1/T2/T3 [34:00]–[36:00] |
| R5 | Approval routing must preserve the manager-review → finance-approval-above-threshold pattern | Confirmed (as current-state; not yet confirmed as target-state requirement) | T1/T2/T3 [06:00] |
| R6 | Target timing: "before the next quarter" | Confirmed as stated, but no date/quarter/year specified | T1/T2/T3 [32:00] |
| R7 | Exact approval dollar threshold | **Not confirmed** | — |
| R8 | Full list of permission levels/roles beyond "manager vs. employee" | **Not confirmed** — Mike states BA "will document those roles" but the roles themselves are not enumerated in transcript | T1/T2/T3 [26:00]–[28:00] |

## 5. Decisions & Rationale

| Decision | Rationale stated | Decided by | Source |
|---|---|---|---|
| Scope v1 to the biggest problems rather than the full process | Faster delivery; features can be added later | Lisa (proposed), Sarah (agreed) | T1/T2/T3 [16:00]–[18:00] |
| Build role-based permissions into the solution | Managers require different information visibility than regular employees | Emily (stated need), team (accepted) | T1/T2/T3 [24:00]–[26:00] |
| Prioritize monthly summary reporting over other reports | Named "the biggest priority" by the stakeholder | Emily | T1/T2/T3 [34:00]–[36:00] |
| Defer technical approach decision until existing data is reviewed | Team wants to review existing data/systems before committing to a technical approach | David | T1/T2/T3 [38:00] |

No approval thresholds, budget figures, technology stack, or vendor decisions were confirmed in these sessions.

## 6. Risks, Assumptions, Issues, and Dependencies

| Type | Item | Source |
|---|---|---|
| Issue | Duplicate data entry across multiple systems is the root cause of process slowness | T1/T2/T3 [02:00] |
| Issue | Manual, non-integrated systems increase approval and reporting lag | T1/T2/T3 [12:00]–[14:00] |
| Dependency | Technical approach is dependent on the Developer's review of existing data/systems (not yet completed at time of meeting) | T1/T2/T3 [38:00] |
| Dependency | Complete requirements documentation depends on planned follow-up interviews with other departments (not yet scheduled with names/dates) | T1/T2/T3 [40:00] |
| Assumption | An approval-amount threshold exists today; exact value **Not confirmed** | T1/T2/T3 [06:00] |
| Risk | "Before next quarter" target has no confirmed date — schedule risk if not clarified before build starts | T1/T2/T3 [32:00] |
| Risk | Identical content across all three transcripts (see Data-Quality Flag) suggests the requirements picture has not actually advanced across three logged sessions — risk that stated "next steps" (interviews, sample reports, system review) are still outstanding | See Section "Data-Quality Flag" |

## 7. Open Questions & Information Gaps

All items below are **Not confirmed** in the reviewed transcripts:

- What is the exact dollar/amount threshold that triggers finance approval?
- What specific systems and spreadsheets make up today's process?
- What is the confirmed target delivery date (specific quarter and year)?
- What is the complete set of permission levels/roles beyond "manager" and "regular employee"?
- Which "other departments" will Mike interview, and when?
- What reports beyond the monthly summary are in scope, and in what priority order?
- Is transcript duplication (Section: Data-Quality Flag) a filing error, or did three distinct meetings genuinely produce identical minutes? This must be resolved before treating later "workshops" as incremental progress.

## 8. Action Register

| # | Action | Owner | Timing | Status | Source |
|---|---|---|---|---|---|
| A1 | Document requirements | Mike (Business Analyst) | Not confirmed (no date given) | Open | T1/T2/T3 [28:00], "Action Items" |
| A2 | Send sample spreadsheets/reports used today | Emily (Stakeholder) | Not confirmed (no date given) | Open | T1/T2/T3 [44:00], "Action Items" |
| A3 | Review existing systems/data before deciding technical approach | David (Developer) | Not confirmed (no date given) | Open | T1/T2/T3 [38:00], "Action Items" |
| A4 | Schedule the next workshop | Sarah (Project Manager) | "Next week" (relative, no calendar date confirmed) | Open | T1/T2/T3 [46:00], "Action Items" |
| A5 | Schedule follow-up interviews with other departments | Mike (Business Analyst) | Not confirmed | Open | T1/T2/T3 [40:00] |

## 9. Prioritized Requirements Backlog (with Acceptance Questions)

| Priority | Backlog Item | Basis | Acceptance Question(s) for Next Workshop |
|---|---|---|---|
| 1 | MVP request-submission workflow (single entry point, no duplicate data entry) | T1/T2/T3 [02:00], [16:00] | What counts as "biggest problems" for v1 — is single-entry submission explicitly in scope? |
| 2 | Configurable finance approval routing with amount threshold | T1/T2/T3 [06:00] | What is the exact threshold amount, and can it change over time (config vs. hardcoded)? |
| 3 | Role-based access control (manager vs. employee views, minimum) | T1/T2/T3 [24:00]–[26:00] | What is the full list of roles/permission levels, and what does each role see/do? |
| 4 | Monthly summary report | T1/T2/T3 [36:00] | What data fields, format, and audience does the monthly summary need? Is this a dashboard, export, or scheduled email? |
| 5 | System/data integration scope (replacing manual spreadsheet updates) | T1/T2/T3 [10:00], [14:00], [38:00] | Which specific current systems must the new application read from or replace? |
| 6 | Additional reports beyond monthly summary | T1/T2/T3 [34:00] | Are there other reports beyond monthly summary, and what priority order? |
| 7 | Delivery timeline confirmation | T1/T2/T3 [32:00] | What is the exact target date (quarter + year)? Is "before next quarter" firm or aspirational? |

## 10. Highest-Value Follow-Up Questions for the Next Workshop

1. **Data integrity:** Transcripts 1, 2, and 3 contain identical dialogue and action items. Were these genuinely three separate sessions, or is this a single transcript filed under three titles? If separate, what changed between them?
2. What is the specific dollar/amount threshold that triggers finance approval today?
3. What is the confirmed target delivery date (exact quarter and year), and is it firm or aspirational?
4. What specific legacy systems/spreadsheets are in scope for replacement or integration?
5. Beyond "manager" and "regular employee," what is the complete list of roles and their permitted actions/visibility?
6. Which departments will the Business Analyst interview, and can those be scheduled now with named contacts and dates?
7. Has Emily sent the sample reports/spreadsheets referenced in Action Item A2? If not, when will they be available, since several backlog items depend on them?
8. Beyond the monthly summary, are there other reports required for the v1 release, and in what order of priority?

---

### Evidence Classification Key
- **Confirmed** — directly and explicitly stated in a transcript, cited with timestamp.
- **Reasonable inference** — a logical implication drawn from confirmed statements, explicitly marked as such above (none required beyond what is noted inline).
- **Not confirmed** — no transcript statement establishes this; must not be treated as fact or used as a basis for a downstream decision until validated with the stakeholder.
