#!/usr/bin/env python3
"""
Extract text from Teams-transcript PDFs and print each with a source label,
so every downstream finding can be cited as "<filename> [<timestamp>]".

Usage:
    python3 extract_transcripts.py <file1.pdf> [file2.pdf ...]
    python3 extract_transcripts.py assets/*.pdf
"""
import sys
from pathlib import Path

from pypdf import PdfReader


def extract(pdf_path: str) -> str:
    reader = PdfReader(pdf_path)
    return "\n".join(page.extract_text() or "" for page in reader.pages)


def main(argv: list[str]) -> int:
    if not argv:
        print(__doc__)
        return 1

    for path in argv:
        p = Path(path)
        if not p.exists():
            print(f"SKIP (not found): {path}", file=sys.stderr)
            continue
        print(f"===== {p.name} =====")
        print(extract(str(p)))
        print()
    return 0


if __name__ == "__main__":
    raise SystemExit(main(sys.argv[1:]))
