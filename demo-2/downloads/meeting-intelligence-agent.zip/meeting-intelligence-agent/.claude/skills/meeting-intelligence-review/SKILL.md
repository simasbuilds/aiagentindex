---
name: meeting-intelligence-review
description: Consolidate Microsoft Teams (or similar) meeting transcript PDFs into an evidence-based project delivery brief. Use when the user provides multiple meeting transcripts (kickoff, requirements gathering, discovery, workshops) and wants a PM/BA-style consolidated analysis — business problem, stakeholders, requirements, decisions, risks, open questions, and an action register — with every claim traceable to a source transcript and timestamp.
---

# Meeting Intelligence Review

Turn a set of meeting transcripts into a single, evidence-based delivery brief for a project record. Acts as a senior Project Manager / Business Analyst: extracts facts, never invents them, and cites every material finding back to its source.

## When to use this skill

- The user supplies two or more meeting transcripts (PDF, DOCX, or plain text) covering the same project or initiative and asks for a consolidated summary, requirements extraction, or delivery brief.
- The user asks to identify decisions, action items, risks, or open questions "across" multiple meetings.
- The user asks you to spot duplicate or conflicting statements between meetings.

Do not use this skill for a single ad-hoc meeting note with no cross-referencing need — a plain summary is enough there.

## Tools

`scripts/extract_transcripts.py` — extracts raw text from one or more transcript PDFs using `pypdf`, printing each under a `===== <filename> =====` header so timestamps and speaker lines can be read and cited directly from the output.

```bash
python3 scripts/extract_transcripts.py assets/*.pdf
```

If the source files are DOCX or TXT instead of PDF, read them directly with the Read tool — this script is PDF-specific. If a PDF returns no text (scanned/image-based), fall back to OCR (see the `pdf` skill's OCR section) before proceeding; do not analyze a transcript you can't actually read.

## Method

1. **Extract every transcript first, in full**, before drawing any conclusion. Never summarize from a partial read.
2. **Diff the transcripts against each other.** Meeting-to-meeting, look for:
   - Verbatim or near-verbatim duplicated passages (flag this — it changes how much independent corroboration the evidence actually provides; do not let duplicated text be double- or triple-counted as agreement across meetings).
   - Direct contradictions (e.g., two stated deadlines, two different owners for the same action item).
   Surface both explicitly in the brief; don't silently resolve a conflict by picking one side.
3. **Extract into these categories**, each traceable to source:
   - Business problem and current-state workflow
   - Users and stakeholders (name, role, what they said/decided)
   - Confirmed requirements and constraints
   - Decisions and the rationale given for each
   - Risks, assumptions, issues, dependencies
   - Open questions / information gaps
   - Action items with owner and any stated timing
4. **Citation rule:** every material finding gets `(<transcript filename> [<timestamp>])`. A finding with no timestamp/transcript backing it does not go in the "Confirmed" sections.
5. **Never invent.** Do not fill in a requirement, owner, due date, approval threshold, budget figure, or technical decision that was not explicitly stated. If it's implied but not stated, label it "Reasonable inference" and say what it's inferred from. If it's simply missing, label it "**Not confirmed**".
6. **Classify every claim** into exactly one of: Confirmed (explicit + cited), Reasonable inference (explicit basis + noted as inference), Not confirmed (gap — do not treat as fact downstream).

## Output structure

Produce, in this order:

1. **Executive summary** — 2–3 paragraphs, cites key facts inline.
2. **Findings table(s)** with a source-evidence column for every row.
3. **Action register** — columns: Action, Owner, Timing, Status, Source. Use "Not confirmed" for owner/timing when the transcript doesn't state them — never leave blank or guess.
4. **Prioritized requirements backlog** — each item paired with an acceptance question to ask at the next workshop (what would need to be confirmed to build this).
5. **Highest-value follow-up questions** for the next workshop — prioritize questions that unblock the most backlog items or resolve the biggest confirmed gaps/conflicts.

Save the brief as a Markdown file (e.g., `deliverables/Project_Delivery_Brief.md`) so it's diffable and versionable. Offer to render it as an Artifact when the user wants a shareable, readable view — do not publish it automatically if it references people by name in a way the user hasn't indicated is shareable.
