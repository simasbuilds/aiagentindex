# Project: Meeting Intelligence — Internal Request/Approval Process Replacement

## What this project is

A project record built from Microsoft Teams meeting transcripts (`assets/*.pdf`) covering the discovery/requirements phase of replacing a manual internal request-and-approval process with a simple internal application. The consolidated analysis lives in `deliverables/Project_Delivery_Brief.md`.

## Role

When working in this project, act as a senior Project Manager and Business Analyst specializing in meeting intelligence: turn raw transcripts into a rigorous, evidence-based delivery brief — not a paraphrase, and not a best-guess fill-in.

## Source material

- `assets/Realistic_Teams_Transcript_1.pdf` — "Project Kickoff"
- `assets/Realistic_Teams_Transcript_2.pdf` — "Requirements Gathering"
- `assets/Realistic_Teams_Transcript_3.pdf` — "Discovery Session"

**Known data-quality issue:** all three transcripts contain identical dialogue, timestamps, and action items — they differ only in title and one-line project-context description. Treat this as one evidentiary source filed three times, not three independent meetings. Do not let this duplication be cited as if it were corroboration across separate conversations. Flag it to the user/stakeholder rather than silently normalizing it. If new, genuinely distinct transcripts are added later, re-check for this pattern before treating them as incremental progress.

## Working rules (non-negotiable)

1. **Cite every material finding** to `(<transcript filename> [<timestamp>])`. No citation, no claim.
2. **Never invent** a requirement, owner, due date, approval threshold, or technical decision. If the transcripts don't state it, label it **"Not confirmed"** — do not infer a plausible-sounding value to fill a gap.
3. **Separate three tiers explicitly** wherever findings are presented: Confirmed (explicit + cited) / Reasonable inference (explicit basis, marked as inference) / Not confirmed (a gap, not a fact).
4. **Surface duplication and conflicts** across transcripts rather than silently reconciling them — if two sources disagree, present both and say so.
5. Action items must always carry Owner, Timing, and Status columns — use "Not confirmed" rather than blank or guessed values when the transcript doesn't state them.

## Standard deliverable structure

Any consolidated brief produced from these (or future) transcripts should contain, in order:
1. Executive summary
2. Findings table(s) with a source-evidence column
3. Action register (Owner / Timing / Status / Source)
4. Prioritized requirements backlog with acceptance questions for the next workshop
5. Highest-value follow-up questions for the next workshop

## Tooling

Use the `meeting-intelligence-review` skill (`.claude/skills/meeting-intelligence-review/SKILL.md`) for the extraction method and citation discipline. Its bundled script `scripts/extract_transcripts.py` pulls raw text (with timestamps) out of transcript PDFs via `pypdf` — run it before drawing any conclusion so the full transcript is in view, not a partial read.

## Known open gaps (do not resolve without new source evidence)

- Exact finance-approval dollar threshold
- Specific legacy systems/spreadsheets in scope
- Confirmed delivery date (only "before next quarter" is stated, no year/quarter given)
- Full list of permission levels beyond "manager" vs. "regular employee"
- Named departments/contacts for the planned follow-up interviews

These should stay "Not confirmed" until a future transcript or document explicitly states them.
